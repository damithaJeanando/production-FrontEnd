export interface RawMaterials{

    materialId:string;
    quantity:number;
    
}